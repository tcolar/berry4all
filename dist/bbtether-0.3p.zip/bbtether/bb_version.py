'''
Version file
'''
VERSION="0.3m"
